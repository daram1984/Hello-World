# example-tomcat-war

This is an example java build and deploy of the resulting
war file to a tomcat 7 server.

